﻿/**
 * CardBox.cs - The CardBox Class
 * 
 * This class used a custom user control to make a box to hold a card image
 * 
 * @author  Justin Waltenbury
 * @version 1.0
 * @since   March 24, 2018
 * @see     Tutorial Videos by Thom MacDonald
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JustinCards;

namespace CardBox
{
    /// <summary>
    /// A control to use in a Windows Forms Application that displays a playing card.
    /// </summary>
    public partial class CardBox: UserControl
    {

        #region FIELDS AND PROPERTIES

        /// <summary>
        /// Card Property: Gets/sets the underlying Card object.
        /// </summary>
        private PlayingCard myCard;
        public PlayingCard Card
        {
            get { return myCard; }
            set
            {
                myCard = value;
                UpdateCardImage(); //Update the card image
            }
            
        }

        /// <summary>
        /// Suit Property: Gets/sets the underyling Card object's Suit.
        /// </summary>
        public CardSuit Suit
        {
            get { return Card.Suit; }
            set
            {
                Card.Suit = value;
                UpdateCardImage(); //Update the card image
            }            
        }

        /// <summary>
        /// Rank Property: Gets/sets the underyling Card object's Rank.
        /// </summary>
        public CardRank Rank
        {
            get { return Card.Rank; }
            set
            {
                Card.Rank = value;
                UpdateCardImage(); //Update the card image
            }
        }

        /// <summary>
        /// FaceUp Property: Gets/sets the underlying Card object's FaceUp property.
        /// </summary>
        public bool FaceUp
        {
            get { return Card.FaceUp; }
            set
            {
                //If value is different than the underlying card's FaceUp property
                if (myCard.FaceUp != value) //Then the card is flipping over.
                {
                    myCard.FaceUp = value; //Change the card's FaceUp property

                    UpdateCardImage(); //Update the card image (back or front)

                    //If there is an event handler for CardFlipped in the client program
                    if (CardFlipped != null)
                        CardFlipped(this, new EventArgs()); //Call it
                }
            }
        }

        /// <summary>
        /// CardOrientation Property: Gets/sets the Orientation of the card.
        /// If setting this property changes the state of control, swaps
        /// the height and width of the control and updates the image.
        /// </summary>
        private Orientation myOrientation;
        public Orientation CardOrientation
        {
            get { return myOrientation; }
            set
            {
                //If value is different than myOrientation
                if (myOrientation != value)
                {
                    myOrientation = value; //Change the orientation
                    //Swap the height and width of the control
                    this.Size = new Size(Size.Height, Size.Width);

                    //Update the card image
                    UpdateCardImage(); //Update the card image
                }
            }
        }

        /// <summary>
        /// UpdateCardImage Helper Method: Sets the PictureBox image using
        /// the underlying card and the orientation
        /// </summary>
        private void UpdateCardImage()
        {
            //Set the image using the underlying card
            pbMyPictureBox.Image = myCard.GetCardImage();

            //If the orientation is horizontal
            if (myOrientation == Orientation.Horizontal)
            {
                //Rotate the image
                pbMyPictureBox.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            }
        }

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Constructor (Default): Constructs the control with a new card, oriented vertically.
        /// </summary>
        public CardBox()
        {
            InitializeComponent(); //Required method for Designer support.
            myOrientation = Orientation.Vertical; //Set the orientation to vertical.
            myCard = new PlayingCard(); //Create a new underlying card.
        }

        /// <summary>
        /// Constrctor (PlayingCard, Orientation): Constructs the control using parameters.
        /// </summary>
        /// <param name="card">Underlying PlayingCard object</param>
        /// <param name="orientation">Orientation enumeration. Vertical by default</param>
        public CardBox(PlayingCard card, Orientation orientation = Orientation.Vertical)
        {
            InitializeComponent(); //Required method for Designer support.
            myOrientation = orientation; //Set the orientation.
            myCard = card; //Set the underlying card
        }
        #endregion

        #region EVENTS AND EVENT HANDLERS

        /// <summary>
        /// An event handler for the Load event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CardBox_Load(object sender, EventArgs e)
        {
            UpdateCardImage(); //Update card image.
        }

        /// <summary>
        /// An event the client program can handle when the card flips face up/down
        /// </summary>
        public event EventHandler CardFlipped;

        /// <summary>
        /// An event the client program can handle when the user clicks the control
        /// </summary>
        new public event EventHandler Click;

        /// <summary>
        /// An event handler for the user clicking the picturebox control
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbMyPictureBox_Click(object sender, EventArgs e)
        {
            if (Click != null) //If there is a handler for clicking the control in the client program
                Click(this, e); //Call it
        }

        #endregion

        #region OTHER METHODS

        /// <summary>
        /// ToString: Overrides System.Object.ToString()
        /// </summary>
        /// <returns>The name of the card as a string</returns>
        public override string ToString()
        {
            return myCard.ToString();
        }

        #endregion
 
    }
}
