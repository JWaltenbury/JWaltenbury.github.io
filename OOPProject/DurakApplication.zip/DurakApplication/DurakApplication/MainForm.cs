﻿/**
 * MainForm.cs - The main form for the game
 * 
 * Used as the primary gameplay area for the application
 * 
 * @author  Justin Waltenbury
 * @version 1.0
 * @since   April 19, 2018
 * @see     FormUIDemo by Thom MacDonald
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JustinCards;
using CardBox;

namespace DurakApplication
{
    public partial class frmMainForm : Form
    {

        #region Fields and Properties

        /// <summary>
        /// Amount that CardBoxes increase when hovered
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        private const int POP = 25;

        /// <summary>
        /// The default size for a CardBox
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        static private Size regularSize = new Size(75, 107);

        //TODO:
        /// <summary>
        /// Used to generate PlayingCard objects from a Durak Deck
        /// </summary>
        //private CardDealer myDealer = new CardDealer(new Deck(false));

        /// <summary>
        /// The About form
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        private frmAboutForm aboutForm;

        #endregion



        #region Form and Static Control Event Handlers
        
        /// <summary>
        /// frmMainForm constructor
        /// </summary>
        public frmMainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes the deck to be ready to play
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmMainForm_Load(object sender, EventArgs e)
        {
            ResetGame();
        }

        /// <summary>
        /// Closes the application, with confirmation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnQuit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you would like to quit?", "Quit Game", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        /// <summary>
        /// Resets the game, with confirmation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to reset?", "Reset Game", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                ResetGame();
            }
        }

        /// <summary>
        /// Opens the About form when lblAbout is clicked
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lblAbout_Click(object sender, EventArgs e)
        {
            //Check if form exists
            if (aboutForm == null)
            {
                //Create the form
                aboutForm = new frmAboutForm();
            }

            //Open the form
            aboutForm.ShowDialog();
        }

        /// <summary>
        /// Deck click event. Causes the player to draw a card, which adds it to their hand by
        /// creating a CardBox and wiring events to it. Then resizes the entire player hand.
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbxDeck_Click(object sender, EventArgs e)
        {
            //Check if the cards have run out
            if (pbxDeck.Image == null)
            {
                //Reset the game
                //TODO
            }
            else //Draw a card
            {
                //Add card to player's hand, their turn
                PlayingCard card = new PlayingCard();

                //TODO
                //PlayingCard = DurakDeck.Draw();

                //Create new CardBox for the card
                CardBox aCardBox = new CardBox(card);

                //Add click event
                aCardBox.Click += CardBox_Click;

                //Add mouse in event (pop out card)
                aCardBox.MouseEnter += CardBox_MouseEnter;

                //Add mouse out event (return to normal)
                aCardBox.MouseLeave += CardBox_MouseLeave;

                //Add the control to the player's hand
                pnlPlayerHand.Controls.Add(aCardBox);

                //Rescale all the cards
                RealignCards(pnlPlayerHand);
            }

            //TODO
            //Update card counter
            //lblCardsRemaining.Text = DurakDeck.CardsRemaining();
        }

        /// <summary>
        /// Removes the deck image when all the cards have been drawn
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void myDealer_OutOfCards(object sender, EventArgs e)
        {
            pbxDeck.Image = null;
        }

        #endregion



        #region

        /// <summary>
        /// Mouse enter for CardBox, which causes the card to 'grow' and shift upwards
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void CardBox_MouseEnter(object sender, EventArgs e)
        {
            //Convert sender to a CardBox
            CardBox aCardBox = sender as CardBox;

            //Ensure conversion worked
            if (aCardBox != null)
            {
                //Enlarge the card to 'pop'
                aCardBox.Size = new Size(regularSize.Width + POP, regularSize.Height + POP);

                //Shift card to top of panel so it sticks out
                aCardBox.Top = 0;
            }
        }

        /// <summary>
        /// Mouse leave for CardBox, which causes the card to return to its original size
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void CardBox_MouseLeave(object sender, EventArgs e)
        {
            //Convert sender to a CardBox
            CardBox aCardBox = sender as CardBox;

            //Ensure conversion worked
            if (aCardBox != null)
            {
                //Enlarge the card to 'pop'
                aCardBox.Size = regularSize;

                //Shift card back to original position
                aCardBox.Top = POP;
            }
        }

        /// <summary>
        /// Click event for the picture box. First confirms the card is playable, then confirms, then moves the card
        /// to the play area. After, realigns the cards in both areas
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CardBox_Click(object sender, EventArgs e)
        {
            //Convert sender to a CardBox
            CardBox aCardBox = sender as CardBox;

            //Ensure conversion worked
            if (aCardBox != null)
            {
                //TODO
                //Confirm the card is playable

                //Confirm, then move the card to the play area
                DialogResult dialogResult = MessageBox.Show("Play this card?", "Play Card", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    pnlPlayerHand.Controls.Remove(aCardBox); //Remove from player's hand

                    pnlPlayArea.Controls.Add(aCardBox); //Add to play area

                    //Realign cards in both areas
                    RealignCards(pnlPlayerHand);
                    RealignCards(pnlPlayArea);
                }
            }
        }

        #endregion



        #region Helper Methods

        /// <summary>
        /// Used when cards are moved into a panel area either through drawing or dealing, and causes the cards to be equally
        /// spaced throughout the panel using an overlap if necessary. Cards are placed right-to-left, so that the right most
        /// card is on top and the 'bottom' cards only display their rank and suit.
        /// NOTE: Adopted from FormUIDemo by Thom MacDonald
        /// </summary>
        /// <param name="panelToResize"></param>
        private void RealignCards(Panel panelToResize)
        {
            //Determine how many controls there are
            int cardCount = panelToResize.Controls.Count;

            //Check that cards exist
            if (cardCount > 0)
            {
                //Determine card width
                int cardWidth = panelToResize.Controls[0].Width; //All controls are the same, doesn't matter which we pick

                //Determine left-edge of card placed in the middle
                int startingPoint = (panelToResize.Width - cardWidth) / 2;

                //Offset for remaining cards
                int offset = 0;

                //Look for multiple cards
                if (cardCount > 1)
                {
                    //Determine offset, based on available space
                    offset = (panelToResize.Width - cardWidth - 2 * POP) / (cardCount - 1);

                    //If offset is bigger than width, we can set the offset to the card width so they don't overlap
                    if (offset > cardWidth)
                    {
                        offset = cardWidth;
                    }

                    //Determine total width of all the cards
                    int allCardsWidth = (cardCount - 1) * offset + cardWidth;

                    //Set the starting point for the first card (centered)
                    startingPoint = (panelToResize.Width - allCardsWidth) / 2;
                }

                //Align the last card (note that we work back to front, so that left cards are beneath right ones)
                panelToResize.Controls[cardCount - 1].Top = POP;
                panelToResize.Controls[cardCount - 1].Left = startingPoint;

                //Align the remaining cards (still back to front)
                for (int position = cardCount - 2; position >= 0; position--)
                {
                    //Align next card
                    panelToResize.Controls[position].Top = POP;
                    panelToResize.Controls[position].Left = panelToResize.Controls[position + 1].Left + offset;
                }

            }
        }

        /// <summary>
        /// Resets the panels, prepares a new deck, etc.
        /// </summary>
        private void ResetGame()
        {
            //Clear panels
            pnlPlayerHand.Controls.Clear();
            pnlComputerHand.Controls.Clear();
            pnlPlayArea.Controls.Clear();

            //Prepare new deck
            //TODO

            //Set image to card back
            pbxDeck.Image = (new PlayingCard()).GetCardImage();

            //TODO
            //Update card counter
            //lblCardsRemaining.Text = DurakDeck.CardsRemaining();
        }
        #endregion
    }
}
