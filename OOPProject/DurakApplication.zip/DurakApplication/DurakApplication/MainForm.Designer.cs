﻿namespace DurakApplication
{
    partial class frmMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbxDeck = new System.Windows.Forms.PictureBox();
            this.lblCardsRemaining = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblAbout = new System.Windows.Forms.Label();
            this.pnlPlayerHand = new System.Windows.Forms.Panel();
            this.pnlComputerHand = new System.Windows.Forms.Panel();
            this.pnlPlayArea = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeck)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxDeck
            // 
            this.pbxDeck.Location = new System.Drawing.Point(12, 29);
            this.pbxDeck.Name = "pbxDeck";
            this.pbxDeck.Size = new System.Drawing.Size(75, 107);
            this.pbxDeck.TabIndex = 0;
            this.pbxDeck.TabStop = false;
            this.pbxDeck.Click += new System.EventHandler(this.pbxDeck_Click);
            // 
            // lblCardsRemaining
            // 
            this.lblCardsRemaining.AutoSize = true;
            this.lblCardsRemaining.Location = new System.Drawing.Point(12, 9);
            this.lblCardsRemaining.Name = "lblCardsRemaining";
            this.lblCardsRemaining.Size = new System.Drawing.Size(24, 17);
            this.lblCardsRemaining.TabIndex = 1;
            this.lblCardsRemaining.Text = "52";
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(12, 468);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 2;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(12, 439);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.Location = new System.Drawing.Point(1031, 9);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(45, 17);
            this.lblAbout.TabIndex = 4;
            this.lblAbout.Text = "About";
            this.lblAbout.Click += new System.EventHandler(this.lblAbout_Click);
            // 
            // pnlPlayerHand
            // 
            this.pnlPlayerHand.Location = new System.Drawing.Point(97, 341);
            this.pnlPlayerHand.Name = "pnlPlayerHand";
            this.pnlPlayerHand.Size = new System.Drawing.Size(980, 150);
            this.pnlPlayerHand.TabIndex = 5;
            // 
            // pnlComputerHand
            // 
            this.pnlComputerHand.Location = new System.Drawing.Point(97, 29);
            this.pnlComputerHand.Name = "pnlComputerHand";
            this.pnlComputerHand.Size = new System.Drawing.Size(980, 150);
            this.pnlComputerHand.TabIndex = 6;
            // 
            // pnlPlayArea
            // 
            this.pnlPlayArea.Location = new System.Drawing.Point(95, 185);
            this.pnlPlayArea.Name = "pnlPlayArea";
            this.pnlPlayArea.Size = new System.Drawing.Size(980, 150);
            this.pnlPlayArea.TabIndex = 6;
            // 
            // frmMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 503);
            this.Controls.Add(this.pnlPlayArea);
            this.Controls.Add(this.pnlComputerHand);
            this.Controls.Add(this.pnlPlayerHand);
            this.Controls.Add(this.lblAbout);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.lblCardsRemaining);
            this.Controls.Add(this.pbxDeck);
            this.Name = "frmMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Durak";
            this.Load += new System.EventHandler(this.frmMainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxDeck;
        private System.Windows.Forms.Label lblCardsRemaining;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Panel pnlPlayerHand;
        private System.Windows.Forms.Panel pnlComputerHand;
        private System.Windows.Forms.Panel pnlPlayArea;
    }
}

