﻿/**
 * PlayingCard.cs - The PlayingCard Class
 * 
 * This class is used to represent the standard card of a standard playing card deck.
 * 
 * @author  Justin Waltenbury
 * @version 1.0
 * @since   March 24, 2018
 * @see     Tutorial Videos by Thom MacDonald
 */

//Attribution:
//Card images adopted from https://opengameart.org/content/playing-cards-vector-png, which originally adopted them
//  from Byron Knoll (https://code.google.com/archive/p/vector-playing-cards/). The license is listed as 'Other Open Source'
//Card back adopted from http://www.maxplayingcards.com/en/2014/01/04/different-deck-a-completely-different-deck/

using System;
using System.Drawing; // (Add a reference) Needed for System.Drawing.Image

namespace JustinCards
{
    /// <summary>
    /// Used to represent a standard 'French' playing cad that can be used
    /// in several card game projects.
    /// </summary>
    public class PlayingCard : ICloneable, //Supports cloning, which creates a new
            // instance of a class with the same value as an existing instance.
                               IComparable //Defines a generalized type-specific
            // comparison method that a class implements
            // to sort its instances.
    {

        #region FIELDS AND PROPERTIES

        /// <summary>
        /// Suit Property
        /// Used to set or get the Card Suit
        /// </summary>
        protected CardSuit mySuit;
        public CardSuit Suit
        {
            get { return mySuit; } //return the suit
            set { mySuit = value; } //set the suit
        }

        /// <summary>
        /// Rank Property
        /// Used to set or get the Card Rank
        /// </summary>
        protected CardRank myRank;
        public CardRank Rank
        {
            get { return myRank; } //return the rank
            set { myRank = value; } //set the rank
        }

        /// <summary>
        /// CardValue property
        /// Used to set or get the Card Value
        /// </summary>
        protected int myValue;
        public int CardValue
        {
            get { return myValue; } //return the value
            set { myValue = value; } //set the value
        }

        /// <summary>
        /// Alternate Value Property
        /// Used to set or get an alternate value for certain games. Set to null by default.
        /// </summary>
        protected int? altValue = null; //nullable type
        public int? AlternateValue
        {
            get { return altValue; } //return the alt value
            set { altValue = value; } //set the alt value
        }

        /// <summary>
        /// FaceUp Property
        /// Used to set or get whether the card is face up.
        /// Set to false by default.
        /// </summary>
        protected bool faceUp = false;
        public bool FaceUp
        {
            get { return faceUp; } //return whether the card is face up
            set { faceUp = value; } //set whether the card is face up
        }

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Card Constructor
        /// Initialized the playing card object. By default, card is shown face down, with no alternate value.
        /// </summary>
        /// <param name="rank"></param>
        /// <param name="suit"></param>
        public PlayingCard(CardRank rank = CardRank.Ace, CardSuit suit = CardSuit.Hearts)
        {
            //Set the rank, suit
            this.myRank = rank;
            this.mySuit = suit;

            //Set the default card value
            this.myValue = (int)rank;
        }

        #endregion

        #region PUBLIC METHODS

        /// <summary>
        /// CompareTo Method
        /// Card-specific comparison method used to sort Card instances. Compares this instance to one passed as an argument
        /// </summary>
        /// <param name="obj">The object this card is being compared to</param>
        /// <returns>An integer that indicates whether this Card precedes, follows, or occurs in the same position</returns>
        public virtual  int CompareTo(object obj)
        {
            //Is the argument null?
            if (obj == null)
            {
                //Throw an argument null exception
                throw new ArgumentNullException("Unable to compare a Card to a null object.");
            }

            //Convert the argument to a Card
            PlayingCard compareCard = obj as PlayingCard;

            //If the conversion worked
            if (compareCard != null)
            {
                //Compare based on Value first, then Suit.
                int thisSort = this.myValue * 10 + (int)this.mySuit;
                int compareCardSort = compareCard.myValue * 10 + (int)compareCard.mySuit;
                return (thisSort.CompareTo(compareCardSort));
            }
            else //Otherwise, the conversion failed
            {
                //Throw an argument exception
                throw new ArgumentException("Object being compared to cannot be converted to a Card.");
            }
        } //End of CompareTo

        /// <summary>
        /// CloneMethod
        /// To suport the ICloneable interface. Used for deep copying in card collection classes.
        /// </summary>
        /// <returns>A copy of the card as a System.Object</returns>
        public object Clone()
        {
            return this.MemberwiseClone(); //Returns a memberwise clone.
        }

        /// <summary>
        /// ToString : Overrides System.Object.ToString()
        /// </summary>
        /// <returns>The name of the card as a string</returns>
        public override string ToString()
        {
            string cardString; //Holds the playing card name.

            //If the card is face up
            if (faceUp)
            {
                //If the card is a Joker
                if (myRank == CardRank.Joker)
                {
                    //Set the card name string to {Red|Black} Joker
                    //If the suit is black
                    if (mySuit == CardSuit.Clubs || mySuit == CardSuit.Spades)
                    {
                        //Set the name string to black joker
                        cardString = "Black Joker";
                    }
                    else //The suit must be red
                    {
                        //Set the name string to red joker
                        cardString = "Red Joker";
                    }
                }
                else //Otherwise, the card is a face up but not a joker
                {
                    //Set the card name string to {Rank} of {Suit}
                    cardString = myRank.ToString() + " of " + mySuit.ToString();
                }
            }
            else //Otherwise, the card is face down.
            {
                //Set the card name to face down.
                cardString = "Face Down";
            }

            //Return the appropriate card name string
            return cardString;
        }

        /// <summary>
        /// Equals: Overrides System.Object.Equals()
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>True if the card values are equal</returns>
        public override bool Equals(object obj)
        {
            return (this.CardValue == ((PlayingCard)obj).CardValue);
        }

        /// <summary>
        /// GetHashCode: Overrides System.Object.GetHashCode()
        /// </summary>
        /// <returns>Card value * 10 + Suit number</returns>
        public override int GetHashCode()
        {
            return this.myValue * 100 + (int)this.mySuit * 10 + ((this.faceUp) ? 1 : 0);
        }

        /// <summary>
        /// GetCardImage
        /// Gets the image associated with the card from the resource file.
        /// </summary>
        /// <returns>An image corresponding to the playing card.</returns>
        public Image GetCardImage()
        {
            string imageName; //The name of the image in the resources file
            Image cardImage; //Holds the image

            //If the card is not face up
            if(!faceUp)
            {
                //Set the image name to "Back"
                imageName = "Back"; //Sets it to the image name for the back of a card
            }
            else if(myRank == CardRank.Joker) //If the card is a joker
            {
                //If the suit is black
                if (mySuit == CardSuit.Clubs || mySuit == CardSuit.Spades)
                {
                    //Set the image to black joker
                    imageName = "Black_Joker";
                }
                else //The suit must be red
                {
                    //Set the image to red joker
                    imageName = "Red_Joker";
                }
            }
            else //Otherwise, the card is face up and not joker
            {
                //Set the image name to {Suit}_{Rank}
                imageName = mySuit.ToString() + "_" + myRank.ToString(); //Enumerations are handy!
            }

            //Set the image to the appropriate object we get from the resources file
            cardImage = Properties.Resources.ResourceManager.GetObject(imageName) as Image;

            //Return the image
            return cardImage;         
        }

        /// <summary>
        /// DebugString
        /// Generates a string showing the state of the card object; useful for debug purposes.
        /// </summary>
        /// <returns>A string showing the state of this card object</returns>
        public string DebugString()
        {
            string cardState = (string)(myRank.ToString() + " of " + mySuit.ToString()).PadLeft(20);
            cardState += (string)((FaceUp) ? "(Face Up)" : "(Face Down)").PadLeft(12);
            cardState += " Value: " + myValue.ToString().PadLeft(2);
            cardState += ((altValue != null) ? "/" + altValue.ToString() : "");

            return cardState;
        }

        #endregion

        #region RELATIONAL OPERATORS

        /// <summary>
        /// == operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator ==(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue == right.CardValue); //True if equal
        }

        /// <summary>
        /// != operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator !=(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue != right.CardValue); //True if not equal
        }

        /// <summary>
        /// Less than operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator <(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue < right.CardValue); //True if left is lower
        }

        /// <summary>
        /// Less than or equal operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator <=(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue <= right.CardValue); //True if left is lower or equal
        }

        /// <summary>
        /// Greater than operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator >(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue > right.CardValue); //True if left is greater
        }

        /// <summary>
        /// Greater than or equal operator that compares the value of the first card to the value of the second card
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        public static bool operator >=(PlayingCard left, PlayingCard right)
        {
            return (left.CardValue <= right.CardValue); //True if left is greater or equal
        }

        #endregion

    } //End of class

} //End of namespace block