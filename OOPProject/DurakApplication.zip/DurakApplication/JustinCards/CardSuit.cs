﻿/**
 * CardSuit.cs - The CardSuit Enumeration
 * 
 * This enumeration is used to represent the 4 'French' suits of a standard playing card deck.
 * 
 * @author  Justin Waltenbury
 * @version 1.0
 * @since   March 24, 2018
 * @see     Tutorial Videos by Thom MacDonald
 */

namespace JustinCards
{
    /// <summary>
    /// CardSuit Enumeration
    /// Used to represent the 4 'French' suits of a standard playing card deck.
    /// </summary>
    public enum CardSuit : byte
    {
        Spades,
        Hearts,
        Diamonds,
        Clubs
    }
}