﻿/**
 * CardRank.cs - The CardRank Enumeration
 * 
 * This enumeration is used to represent the various card ranks of a standard playing card deck
 * 
 * @author  Justin Waltenbury
 * @version 1.0
 * @since   March 24, 2018
 * @see     Tutorial Videos by Thom MacDonald
 */

namespace JustinCards
{
    /// <summary>
    /// CardRank Enumeration
    /// Used to represent the 13 ranks of a standard 'French' playing card deck, plus Joker.
    /// </summary>
    public enum CardRank : byte
    {
        Ace = 1,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Joker
    }
}